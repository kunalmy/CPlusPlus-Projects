# Library Management System

<p>In this Library Management System project, you can enter the record of new books and retrieve the details of books available in the library. You can issue the books to the students and maintain their records. Late fine is charged for students who returns the issued books after the due date.Only one book is issued to students. New book is not issued to students those not returned the last book.</p>

![Screenshot (410)](https://user-images.githubusercontent.com/43209472/93245763-6557ad80-f7a9-11ea-84a2-0cffc1519431.png)
