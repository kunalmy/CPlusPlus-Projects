# Student-Record-Management-System
Student Record Management System is a software solution for tracking and managing student data. 

##### The information contained in SRMS records are the name, roll number, marks and grades of the student. So, the simple file handling cum record management operations users can perform in this project are :-

* Add new record
* Show existing records
* Modify records
* Search records
* Delete records

& all the records will be stored in student.dat file. 

##### Tools and Technologies used in the Project :-

* Language - C++
* IDE - VS Code

## License

Code released under [GNU General Public License v3.0](https://www.gnu.org/licenses/gpl-3.0.en.html) 
